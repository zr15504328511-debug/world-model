# 中性粒细胞四幕白模静态场景

稳定 ID: object.neutrophil-journey-whitebox @ 0.0.1

查看 asset.json、capabilities.json、resources.json 和 validation/latest.json。按实际需要增加 bindings、facts 和 collision；资源预览不声明宿主运行能力。
