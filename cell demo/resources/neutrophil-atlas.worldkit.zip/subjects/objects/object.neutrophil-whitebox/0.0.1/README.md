# 中性粒细胞白模

稳定 ID: object.neutrophil-whitebox @ 0.0.1

查看 asset.json、capabilities.json、resources.json 和 validation/latest.json。按实际需要增加 bindings、facts 和 collision；资源预览不声明宿主运行能力。
